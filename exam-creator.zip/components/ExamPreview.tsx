
import React from 'react';
import { Exam } from '../types';

interface ExamPreviewProps {
  exam: Exam;
}

const ExamPreview: React.FC<ExamPreviewProps> = ({ exam }) => {
  return (
    <div className="print-area">
      {/* Page 1: Table of Specification */}
      <div className="a4-container">
        <div className="text-center border-b-2 border-double border-slate-900 pb-4 mb-6">
          <h2 className="text-2xl font-bold uppercase tracking-widest">{exam.title}</h2>
          <h3 className="text-lg font-semibold text-slate-700">TABLE OF SPECIFICATION</h3>
        </div>

        <div className="overflow-x-auto mb-8">
          <table className="w-full border-collapse border border-slate-800 text-sm">
            <thead className="bg-slate-100">
              <tr>
                <th className="border border-slate-800 p-2 text-left">Learning Competency / Topic</th>
                <th className="border border-slate-800 p-2 text-center">No. of Items</th>
                <th className="border border-slate-800 p-2 text-center">Percentage</th>
                <th className="border border-slate-800 p-2 text-center">Item Placement</th>
              </tr>
            </thead>
            <tbody>
              {exam.tos.map((entry, idx) => (
                <tr key={idx}>
                  <td className="border border-slate-800 p-2">{entry.competency}</td>
                  <td className="border border-slate-800 p-2 text-center">{entry.numItems}</td>
                  <td className="border border-slate-800 p-2 text-center">{entry.percentage}</td>
                  <td className="border border-slate-800 p-2 text-center">{entry.itemPlacement}</td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-50 font-bold">
              <tr>
                <td className="border border-slate-800 p-2 text-right uppercase">Total</td>
                <td className="border border-slate-800 p-2 text-center">
                  {exam.tos.reduce((sum, e) => sum + e.numItems, 0)}
                </td>
                <td className="border border-slate-800 p-2 text-center">100%</td>
                <td className="border border-slate-800 p-2 text-center">-</td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="text-slate-500 italic text-xs no-print">
          Note: This TOS is generated to guide the distribution of items across learning objectives.
        </div>
      </div>

      {/* Page 2: The Exam */}
      <div className="a4-container page-break">
        <div className="text-center border-b pb-6 mb-8">
          <h2 className="text-2xl font-bold text-slate-900 uppercase tracking-tight">{exam.title}</h2>
          <div className="flex justify-between mt-4 text-sm font-medium border-b border-slate-200 pb-2">
            <span>Pangalan: ________________________________</span>
            <span>Petsa: ___________</span>
          </div>
          <p className="text-slate-500 mt-4 italic text-left"><strong>Instructions:</strong> {exam.instructions}</p>
        </div>

        <div className="space-y-6">
          {exam.items.map((item) => (
            <div key={item.no} className="break-inside-avoid">
              <p className="font-semibold text-slate-800 mb-2">
                {item.no}. {item.question}
              </p>
              <div className="grid grid-cols-1 gap-2 pl-6">
                {Object.entries(item.choices).map(([key, value]) => (
                  <div key={key} className="flex items-start gap-2">
                    <span className="font-bold">{key}.</span>
                    <span className="text-slate-700">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Page 3: Answer Key & Rationales */}
      <div className="a4-container page-break">
        <div className="border-b-2 border-slate-900 pb-2 mb-6">
          <h3 className="text-xl font-bold text-slate-900">ANSWER KEY</h3>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {exam.items.map((item) => (
            <div key={item.no} className="flex items-center gap-2 p-2 border border-slate-200 rounded">
              <span className="font-bold text-slate-400 w-8">{item.no}.</span>
              <span className="font-bold text-blue-700 text-lg">{item.answer}</span>
            </div>
          ))}
        </div>

        <div className="no-print">
          <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
            <h3 className="text-lg font-bold text-blue-900 mb-4 flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
              Teacher's Guide (Rationales)
            </h3>
            <div className="space-y-3 text-sm text-blue-800">
              {exam.items.map((item) => (
                <div key={item.no} className="border-b border-blue-100 pb-2">
                  <p><strong>{item.no} ({item.answer}):</strong> {item.rationale}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamPreview;
