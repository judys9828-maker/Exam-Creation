
import { GoogleGenAI, Type } from "@google/genai";
import { Exam, ExamFormData } from "../types";

export const generateExam = async (formData: ExamFormData): Promise<Exam> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `
    You are an expert curriculum developer and teacher. 
    Your task is to generate a classroom exam, a Table of Specification (TOS), and an answer key in valid JSON format.
    
    RULES:
    - Language: ${formData.language}
    - Level: ${formData.gradeLevel}
    - Topic: ${formData.topic}
    - Count: ${formData.itemCount} items
    - Type: Multiple Choice ONLY
    - Content must be age-appropriate and strictly follow the language specified.
    - If Language is Tagalog, use professional Filipino (avoid colloquialisms where appropriate).
    - Distractors (incorrect choices) must be realistic and common misconceptions for the grade level.
    - Provide a short rationale for why the correct answer is correct.
    
    TABLE OF SPECIFICATION (TOS) RULES:
    - Group the ${formData.itemCount} items into 3-5 logical learning competencies or sub-topics related to ${formData.topic}.
    - For each competency, specify:
      1. competency: The name of the learning objective.
      2. numItems: How many questions are assigned to this objective.
      3. percentage: (numItems / totalItems) * 100 formatted as a string (e.g. "20%").
      4. itemPlacement: The range of item numbers (e.g. "1-5").

    OUTPUT SCHEMA:
    {
      "title": "string",
      "instructions": "string",
      "tos": [
        { "competency": "string", "numItems": number, "percentage": "string", "itemPlacement": "string" }
      ],
      "items": [
        {
          "no": number,
          "question": "string",
          "choices": { "A": "string", "B": "string", "C": "string", "D": "string" },
          "answer": "A",
          "rationale": "string"
        }
      ]
    }
  `;

  const prompt = `Generate a ${formData.itemCount}-item ${formData.gradeLevel} exam and its Table of Specification about ${formData.topic} in ${formData.language}.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            instructions: { type: Type.STRING },
            tos: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  competency: { type: Type.STRING },
                  numItems: { type: Type.INTEGER },
                  percentage: { type: Type.STRING },
                  itemPlacement: { type: Type.STRING }
                },
                required: ["competency", "numItems", "percentage", "itemPlacement"]
              }
            },
            items: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  no: { type: Type.INTEGER },
                  question: { type: Type.STRING },
                  choices: {
                    type: Type.OBJECT,
                    properties: {
                      A: { type: Type.STRING },
                      B: { type: Type.STRING },
                      C: { type: Type.STRING },
                      D: { type: Type.STRING }
                    },
                    required: ["A", "B", "C", "D"]
                  },
                  answer: { type: Type.STRING },
                  rationale: { type: Type.STRING }
                },
                required: ["no", "question", "choices", "answer", "rationale"]
              }
            }
          },
          required: ["title", "instructions", "items", "tos"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response text received from Gemini");
    
    return JSON.parse(text) as Exam;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
